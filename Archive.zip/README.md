# Justin Rains' Resume

<<<<<<< .mine
My resume site is built upon the HTML5 boilerplate and Bootstrap 3 with some angularJS.
=======
My resume site is built on the HTML5 boilerplate and Bootstrap 3.
>>>>>>> .r12

<<<<<<< .mine
Are you looking for a professional LAMP developer or front end developer? Email me and I'll get back to you ASAP!=======
Are you looking for a professional LAMP or front end developer? Email me and I'll get back to you ASAP!

Wordpress
CodeIgniter
angularJS
jQuery
JS
HTML5
CSS3
>>>>>>> .r12
